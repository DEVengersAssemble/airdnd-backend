package dao;

import java.util.List;

import vo.AirdndRoomVO;

public interface AirdndRoomDAOI {
	
	List<AirdndRoomVO> select();

	int insert(AirdndRoomVO vo);

}
